package br.com.fiapride.model;

public class Carro {

    public String marca;
    public String motor;
    public int numeroDePortas;

}